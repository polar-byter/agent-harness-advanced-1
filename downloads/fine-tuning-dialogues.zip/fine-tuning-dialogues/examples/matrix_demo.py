"""Маленькие матрицы из рисунков урока; модели и библиотеки не нужны."""


def multiply(left, right):
    """Умножить таблицы: строка слева на столбец справа."""
    result = []
    for row in left:
        new_row = []
        for column in range(len(right[0])):
            total = 0
            for index in range(len(row)):
                total += row[index] * right[index][column]
            new_row.append(total)
        result.append(new_row)
    return result


def main():
    base = [[1, 2], [3, 4]]
    matrix_a = [[1, -1]]
    matrix_b = [[2], [1]]
    vector = [[2], [1]]
    # В рисунке alpha / r = 1, поэтому отдельное масштабирование не нужно.
    correction = multiply(matrix_b, matrix_a)
    effective = []
    for row in range(2):
        effective.append([base[row][column] + correction[row][column] for column in range(2)])
    before = multiply(base, vector)
    after = multiply(effective, vector)
    branch = multiply(matrix_b, multiply(matrix_a, vector))
    assert correction == [[2, -2], [1, -1]]
    assert effective == [[3, 0], [4, 3]]
    assert after == [[before[i][0] + branch[i][0]] for i in range(2)]
    if vector == [[2], [1]]:
        assert before == [[4], [10]] and after == [[6], [11]]
        assert branch == [[2], [1]]
    print("Поправка BA:", correction)
    print("Эффективные веса:", effective)
    print("Выход базы:", [row[0] for row in before])
    print("Выход с поправкой:", [row[0] for row in after])


if __name__ == "__main__":
    main()
